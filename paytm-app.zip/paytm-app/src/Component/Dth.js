import React from 'react'

export default function Dth() {
    return (
        <div>
            DTH recharges
        </div>
    )
}
