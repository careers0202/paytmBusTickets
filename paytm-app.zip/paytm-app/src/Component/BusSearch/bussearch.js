import React, { Component } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './busSearch.css'


// export default function Bussearch() {
//     console.log(useParams())
//     const { source, destination, date } = useParams()
//     return (
//         <div>
//             <h2 className="text-center">Search Route: {source} - {destination}</h2>
//         </div>
//     )
// }

export default class bussearch extends Component {

    constructor() {
        super();
        this.state = {
            busList: [],
            msg: ''
        }
    }

    componentDidMount() {
        const { source, destination } = this.props.match.params;
        //API calls
        // fetch(`http://localhost:8081/list/${source}/${destination}`) // asynchronous
        //     .then(resp => resp.json())
        //     .then(data => this.setState({
        //         busList: data
        //     })) // JSON Object Notation

        axios.get(`http://localhost:8081/list/${source}/${destination}`)
            .then(response => this.setState({
                busList: response.data
            }))
    }

    handleBook = async (bus) => {
        // fetch('http://localhost:8081/book', {
        //     method: 'POST',
        //     body: JSON.stringify(bus)
        // })
        //     .then(resp => resp.json())
        //     .then(data => console.log(data))

        //    const resp =  await fetch('http://localhost:8081/book', {
        //     method: 'POST',
        //     body: JSON.stringify(bus)
        // })
        // const data = await resp.json();

        // axios.post('http://localhost:8081/book', { // asynchronuos way of execution
        //     body: bus
        // })
        //     .then(resp => {
        //         console.log(resp)
        //         if (resp.status == 200) {
        //             this.setState({
        //                 msg: resp.data.msg
        //             })
        //         } else {
        //             this.setState({
        //                 msg: 'Unable to book ticket'
        //             })

        //         }

        //     })

        const resp = await axios.post('http://localhost:8081/book', { // synchronuos way of execution
            body: bus
        })
        console.log(resp);

        if (resp.status == 200) {
            this.setState({
                msg: resp.data.msg
            })
        } else {
            this.setState({
                msg: 'Unable to book ticket'
            })

        }

        console.log('ticket called');
    }

    render() {
        console.log(this.props.match.params)
        const { source, destination, date } = this.props.match.params;
        const { busList, msg } = this.state;
        return (
            <div>
                <h2 className="text-center">Search Route: {source} - {destination}</h2>
                <h3 className="text-success text-center">{msg}</h3>
                {busList.map(bus => {
                    return (
                        <div className="busItem">
                            <h4>{bus.type}</h4>
                            <p>Timings:{bus.time}</p>
                            <b>Price:{bus.price}</b>
                            <button type="button" onClick={() => this.handleBook(bus)}>Book Ticket</button>
                        </div>
                    )
                })
                }
            </div>
        )
    }
}

