import React from 'react'

export default function PageNotFound() {
    return (
        <div>
            <h1>404</h1>
            <h3>Page your looking not found</h3>
        </div>
    )
}
