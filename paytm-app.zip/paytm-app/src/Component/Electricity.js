import React from 'react'

export default function Electricity() {
    return (
        <div>
            <h1> Pay bills</h1>
        </div>
    )
}
