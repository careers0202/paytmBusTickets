import React from 'react'
import { Link } from 'react-router-dom'
import Navbar from './Navbar'

export default function Mobile() {
    return (
        <div>
            <h1>Mobile recharge</h1>
            <Link to="/">Back To Home</Link>
        </div>
    )
}
